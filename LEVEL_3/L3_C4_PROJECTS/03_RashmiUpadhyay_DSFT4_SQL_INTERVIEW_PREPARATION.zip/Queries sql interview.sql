/* 1) Write a query to fetch the first name in the upper case and use the alias name as EmployeeName. */
select upper(fname) as name from employee;
select concat(fname,', ',lname) AS EmployeeName from employee;

/*2) Write a query to fetch the number of employees working in the department ‘HR’.*/
select count(*) from employee where dept='HR';

/*3) Write a query to get the current date.*/
select current_date() AS CurrentDate;

/*4) Write a query to retrieve the first four characters of last name.*/
select  substring(lname,1,4) from employee;

/*5) Write a query to fetch only the place name (string before brackets) from the Address column of Employee table.*/
select substr(address,1,locate('(',address)) from employee;

/*6) Write a query to create a new table that consists of data and structure copied from the other table */
create table NewTable AS select * from employee;
select * from NewTable;

/* 7) Write  q query to find all the employees whose salary is between 50000 to 100000. */
select * from empdesig where salary between '50000' and '100000';

/* 8) Write a query to find the names of employees that begin with ‘S’ */
select * from employee where fname like'S%';

/* 9) Write a query to fetch top N records. */
select * from empdesig  order by salary desc limit 3;

/* 10) Write a query to retrieve the first name and last name in a single column as “Full_Name”. The first 
name and the last name must be separated with space. */
select concat(fname,' ',lname) AS Full_Name from employee;

/* 11) Write a query find number of employees whose date of birth is between 02/05/1970 to 31/12/1975 and are 
grouped according to gender. */
select count(*) from employee where dob between '02 05 1970' AND '31 12 1975' group by gender;

/* 12) Write a query to fetch all the records from the Employee table ordered by LName in descending order and 
Department in the ascending order. */
select * from employee order by lname desc, dept asc;

/* 13) Write a query to fetch details of all employees excluding the employees with first names, “Sanjay” and 
“Sonia” from the Employee table */
select * from employee where fname NOT IN('Sanjay','Sonia');

/* 14) Write a query to fetch details of all employees excluding the employees with first names, “Sanjay” and 
“Sonia” from the Employee table. */
select * from employee where fname NOT IN('Sanjay','Sonia');

/* 15) Write a query to fetch details of employees with the address as “DELHI(DEL)”. */
select * from employee where address like "Delhi (DEL)";

/* 16) Write a query to fetch all employees who also hold the managerial position. */
select e.fname,e.lname,d.desig 
from employee e inner join empdesig d 
on e.empid=d.empid and d.desig in('Manager');

/* 17) Write a query to fetch the department-wise count of employees sorted by department’s count in ascending 
order  */
select dept,count(empid) as empdeptcount from employee
group by dept order by empdeptcount asc;

/* 18) Write a query to calculate the even and odd records from a table. */
select * from employee where empid %2=0;    /* for even */
select * from employee where empid %2 !=0;  /* for odd */

/* 19) Write a SQL query to retrieve employee details from Employee table who have a date of joining in the 
Employee Designation table. */
select * from employee e
where exists (select * from empdesig d where e.empid=d.empid);

/* 20) Write a query to retrieve two minimum and maximum salaries from the Employee Designation table. */
select distinct salary from empdesig emp1 where 2>=(select count(distinct salary) from empdesig emp2
where emp1.salary>=emp2.salary) order by emp1.salary desc;

/* 21) Write a query to find the Nth highest salary from the table without using top/limit keyword */
/* for 2nd highest salary */
select * from empdesig emp1
where (2-1)=(select count(distinct(emp2.salary)) from empdesig emp2
where emp2.salary>emp1.salary);


/* 22) Write a query to retrieve duplicate records from a table */
select empid, fname, dept, COUNT(*) from employee group by empid, fname,dept having count(*) >1;
select fname, lname, count(*) from employee group by fname, lname having count(*)>1;

/* 23) Write a query to retrieve the list of employees working in the same department. */
select distinct e.empid,e.fname, e.dept from employee e, employee e1
where e.dept=e1.dept and e.empid != e1.empid;

/* 24) Write a query to retrieve the last 3 records from the Employee table */
select * from(select * from employee order by empid desc limit 3) t order by empid asc;

/* 25) Write a query to find the third-highest salary from the Employee Designation table. */
select * from empdesig emp1
where (3-1)=(select count(distinct(emp2.salary)) from empdesig emp2
where emp2.salary>emp1.salary);


/* 26) Write a query to display the first and the last record from the Employee table. */
           /* first record */
select * from employee where empid=(select min(empid) from employee);
          /* last record */
select * from employee where empid=(select max(empid) from employee);


/* 27) Write a query to add email validation to your database */
select email from employee where not REGEXP_LIKE(email,'[A-Z0-9._%+-]+@[A-Z0-9.-]+.[A-Z]{2,4}','i');


/* 28) Write a query to retrieve Departments who have less than 2 employees working in it. */
select dept, count(empid) as 'empno' from employee group by dept having count(empid)<2;


/* 29) Write a query to retrieve designation along with total salaries paid for each of them.  */
select  desig, sum(salary) from empdesig group by desig;


/* 30) Write a query to fetch 50% records from the Employee table  */
select * from employee where empid<=(select count(empid)/2 from employee);


 



