create database prep;
use prep;

CREATE TABLE employee (
	empid int primary key,
    fname char (20) not null,
	lname VARCHAR(20),
	dept char (25),
    project char(10),
    address char(40),
    dob date, 
    gender char(1)
	);
    
    CREATE TABLE empdesig (
    empid int not null, 
    desig char(30),
    doj date,
    salary float,
    foreign key (empid) 
    references employee
    (empid)
    );
    
insert into employee values (1, 'Sanjay','Mehra','HR','P1','Hyderabad (HYD)',str_to_date('01 12 1976','%d %m %Y'),'M');
insert into employee values (2, 'Ananya','Mishra','Admin','P2','Delhi (DEL)',str_to_date('02 05 1968', '%d %m %Y'),'F');
insert into employee values (3, 'Rohan', 'Diwan','Account','P3','Mumbai (BOM)',str_to_date('01 01 1980','%d %m %Y'),'M');
insert into employee values (4, 'Sonia','Kulkarni','HR','P1','Hyderabad (HYD)', str_to_date('02 05 1992', '%d %m %Y'),'F');
insert into employee values (5, 'Ankit','Kapoor','Admin','P2','Delhi (DEL)',str_to_date('03 07 1994', '%d %m %Y'),'M');
insert into employee values (6, 'Ankit','Kapoor','Admin','P2','Delhi (DEL)',str_to_date('01 05 1994', '%d %m %Y'),'M');

select * from employee;

insert into empdesig values (1, 'Manager', str_to_date('01 05 2022', '%d %m %Y'), 500000);
insert into empdesig values (2, 'Executive', str_to_date('02 05 2022','%d %m %Y'), 75000);
insert into empdesig values (3, 'Manager' , str_to_date('01 05 2022','%d %m %Y'), 90000);
insert into empdesig values (2, 'Lead', str_to_date('02 05 2022', '%d %m %Y'), 85000);
insert into empdesig values (1, 'Executive', str_to_date('01 05 2022', '%d %m %Y'), 300000);

Select * from empdesig;
















    
 
