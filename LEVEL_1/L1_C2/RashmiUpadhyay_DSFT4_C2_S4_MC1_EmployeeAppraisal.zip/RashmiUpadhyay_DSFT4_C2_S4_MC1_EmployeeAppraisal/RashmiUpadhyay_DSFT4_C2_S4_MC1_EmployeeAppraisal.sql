USE hr;
/* TASK- 1*/
SELECT COUNT(*) AS Total_Number_Of_Employees FROM employees;

/* TASK- 2 */
SELECT department_id, COUNT(*) AS Number_Of_Employees FROM employees GROUP BY department_id;

/* TASK- 3 */
SELECT first_name, salary FROM employees WHERE salary>6000;

/* TASK- 4 */
SELECT COUNT(*) AS Total_No_Of_Empl_Income_Exceeds_20000 FROM employees WHERE salary>20000;

/* TASK- 5 */
SELECT COUNT(*) AS IT_Emp_Sal_Gret_6000 FROM Employees WHERE department_id=60 AND salary>6000;

/* TASK- 6 */
SELECT *, (salary+(salary*commission_pct))*12 as CTC FROM employees;

/* TASK- 7 */
SELECT *, salary+(salary*20)/100 AS Revised_Salary FROM employees WHERE salary BETWEEN 2000 AND 15000;
SELECT *, salary+(salary*10)/100 AS Revised_Salary FROM employees WHERE salary BETWEEN 16000 AND 20000;
SELECT *, salary+(salary*5)/100 AS Revised_Salary FROM employees WHERE salary BETWEEN 21000 AND 25000;


 /* TASK- 8 */
 SELECT * FROM employees WHERE commission_pct IS NOT NULL;
 
 /* TASK- 9 */
 SELECT CONCAT(CONCAT(first_name, ' '),last_name) AS full_name FROM employees WHERE commission_pct IS NULL;
 
 /* TASK- 10 */
 SELECT employee_id, first_name, last_name, email, phone_number FROM employees WHERE commission_pct IS NOT NULL;
 
 /* TASK- 11 */
 SELECT rnk, last_name, department_id, salary FROM(SELECT last_name, department_id, salary, RANK() OVER(PARTITION BY department_id ORDER BY salary DESC) AS rnk FROM employees) employees WHERE rnk<4;
 
 /* TASK- 12 */
  SELECT department_id,SUM(salary) AS CTC FROM employees GROUP BY department_id ORDER BY CTC DESC LIMIT 3;   
  
  /* TASK- 13 */
  SELECT * FROM employees WHERE job_id LIKE '%CLERK%';
  
  /* TASK- 14 */
  SELECT COUNT(*) AS NO_Of_Clerk_Grade_Employees, AVG(salary) FROM employees WHERE job_id LIKE '%CLERK%';
  
  /* TASK- 15 */
  SELECT department_id, COUNT(*) AS Number_Of_Employees FROM employees GROUP BY department_id;
  
  
  /* TASK- 16 */
  SELECT department_id, AVG(salary) AS Average_Salary FROM employees GROUP BY department_id;
  
  /* TASK- 17 */
  SELECT department_id, COUNT(*) AS No_Of_EMP FROM employees WHERE salary BETWEEN 7000 AND 10000 GROUP BY department_id ;
  
  
 

 



