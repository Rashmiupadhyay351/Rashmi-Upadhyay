use sakila;

/* TASK- 1 */
SELECT c.name AS 'Type',SUM(p.amount) AS 'Profit' FROM category c
JOIN film_category fc on (c.category_id=fc.category_id)
JOIN inventory i on (fc.film_id=i.film_id)
JOIN rental r ON (i.inventory_id=r.inventory_id)
JOIN payment p ON (r.rental_id=p.rental_id) GROUP BY c.name ORDER BY Profit DESC LIMIT 5;


/* TASK- 2 */
SELECT film.film_id, film.title, film_actor.actor_id, COUNT(actor_id) FROM film 
JOIN film_actor ON film.film_id=film_actor.film_id GROUP BY actor_id ORDER BY replacement_cost DESC ;


/* TASK- 3 */
SELECT c.name AS 'Genre',SUM(p.amount) AS 'Gross' FROM category c
JOIN film_category fc on (c.category_id=fc.category_id)
JOIN inventory i on (fc.film_id=i.film_id)
JOIN rental r ON (i.inventory_id=r.inventory_id)
JOIN payment p ON (r.rental_id=p.rental_id) GROUP BY c.name ORDER BY Gross DESC;

/* TASK- 4 */
SELECT flm.title, COUNT(*) 'Number of copies in inventory' FROM film flm
INNER JOIN inventory inv ON flm.film_id = inv.film_id WHERE flm.title='BROTHERHOOD BLANKET' OR flm.title ='SOUP WISDOM' GROUP BY title;


/* TASK- 5 */
SELECT c.name AS 'Genre',SUM(p.amount) AS 'Gross' FROM category c
JOIN film_category fc on (c.category_id=fc.category_id)
JOIN inventory i on (fc.film_id=i.film_id)
JOIN rental r ON (i.inventory_id=r.inventory_id)
JOIN payment p ON (r.rental_id=p.rental_id) GROUP BY c.name ORDER BY Gross ASC LIMIT 10;

/* TASK- 6 */
SELECT first_name, last_name, release_year, title FROM film f 
INNER JOIN film_actor fc USING(film_id)
INNER JOIN actor a USING(actor_id)
WHERE description LIKE "%SUMO%" AND description LIKE "%WRESTLER%" ORDER BY last_name LIMIT 5; 


/* TASK- 7 */
SELECT e.country, count(a.rental_id) AS 'No_Of_Movies'
FROM rental a 
LEFT OUTER JOIN customer b ON (a.customer_id=b.customer_id)
LEFT OUTER JOIN address c ON (b.address_id=c.address_id)
LEFT OUTER JOIN city d ON (c.city_id=d.city_id)
LEFT OUTER JOIN country e ON (d.country_id=e.country_id) WHERE country IN ('India', 'United States', 'United Arab Emirates')
GROUP BY  country ORDER BY No_Of_Movies >=1; 









